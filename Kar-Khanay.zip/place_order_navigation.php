<div class="place_order_navigation">
    <a href="cart.php" class="place_order_navigation_Link active">
                    <span class="place_order_navigation_badge">
                        <span>1</span>
                        <i class="fa-solid fa-check"></i>
                    </span>
        My Cart
    </a>
    <i class="fa-solid fa-chevron-right"></i>
    <a href="shipping-info.php" class="place_order_navigation_Link">
                    <span class="place_order_navigation_badge">
                        <span>2</span>
                        <i class="fa-solid fa-check"></i>
                    </span>
        Shipping info
    </a>
    <i class="fa-solid fa-chevron-right"></i>
    <a href="payment-method.php" class="place_order_navigation_Link">
                    <span class="place_order_navigation_badge">
                        <span>3</span>
                        <i class="fa-solid fa-check"></i>
                    </span>
        Payment method
    </a>
    <i class="fa-solid fa-chevron-right"></i>
    <a href="#" class="place_order_navigation_Link">
                    <span class="place_order_navigation_badge">
                        <span>4</span>
                        <i class="fa-solid fa-check"></i>
                    </span>
        Confirmation
    </a>
</div>